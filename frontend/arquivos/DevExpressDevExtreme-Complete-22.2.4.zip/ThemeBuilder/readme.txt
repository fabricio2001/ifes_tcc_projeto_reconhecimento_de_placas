The local DevExtreme ThemeBuilder has been moved to GitHub. To launch it, clone the repo and follow the instructions from README.md. Alternatively, you can use the online version or try our command-line tool for building themes. This tool is part of the DevExtreme CLI project.

Theme Builder on GitHub: https://github.com/DevExpress/devextreme-themebuilder-app
Theme Builder online: https://js.devexpress.com/ThemeBuilder/
DevExtreme CLI on GitHub: https://github.com/DevExpress/devextreme-cli
