﻿"use strict";

var html5elements = ['section', 'article', 'nav', 'header', 'footer'];

for (var i = 0, j = html5elements.length; i < j; i++) {
    document.createElement(html5elements[i]);
}